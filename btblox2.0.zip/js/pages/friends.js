"use strict"

pageInit.friends = () => {}
